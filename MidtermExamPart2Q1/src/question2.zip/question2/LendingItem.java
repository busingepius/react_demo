/**
 * Created by: Businge Pius
 * Company : Gegabox
 * Year : 2024
 * Date : 06/03/2024
 * Time : 10:45
 * Project Name : question2
 */
package question2;

public class LendingItem {
    private Integer numCopiesInLib;
    private ItemType itemType;

    public Integer getNumCopiesInLib(){
        return numCopiesInLib;
    }

    public void setNumCopiesInLib(Integer numCopiesInLib) {
        this.numCopiesInLib = numCopiesInLib;
    }
}
