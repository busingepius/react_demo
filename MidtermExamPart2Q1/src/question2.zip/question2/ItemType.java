package question2;

public enum ItemType {
    Book,CD
}
