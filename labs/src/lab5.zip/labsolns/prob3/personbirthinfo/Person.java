package lesson5.labsolns.prob3.personbirthinfo;

public class Person {
	private String name;
	private BirthInfo birthInfo;
	Person(String name) {
		this.name = name;
	}
}
