/**
 * Created by: Businge Pius
 * Company : Gegabox
 * Year : 2024
 * Date : 02/03/2024
 * Time : 07:42
 * Project Name : lab2
 */
package lab3.two.property;

public class Appartment {
    public double getRent() {
        return rent;
    }

    private double rent;
    Appartment(double rent){this.rent = rent;}
}
