/**
 * Created by: Businge Pius
 * Company : Gegabox
 * Year : 2024
 * Date : 07/03/2024
 * Time : 18:09
 * Project Name : lesson7.labs.prob2
 */
package lesson7.labs.prob2;

public final class EquilateralTriangle implements ClosedCurve{
    public double getSide() {
        return side;
    }

    final private double side;

    public EquilateralTriangle(double side) {
        this.side = side;
    }

    @Override
    public double[] getSides() {
        return new double[]{side,side,side};
    }
}
