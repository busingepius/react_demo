/**
 * Created by: Businge Pius
 * Company : Gegabox
 * Year : 2024
 * Date : 07/03/2024
 * Time : 18:14
 * Project Name : lesson7.labs.prob2
 */
package lesson7.labs.prob2;

public class Ellipse implements ClosedCurve {
    final private double a;
    final private double E;

    public Ellipse(double a, double E) {
        this.a = a;
        this.E = E;
    }

    @Override
    public double computePerimeter() {
        return 4*a*E;
    }
}
