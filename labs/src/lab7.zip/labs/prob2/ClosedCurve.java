package lesson7.labs.prob2;

public interface ClosedCurve extends Polygon{
//	double computePerimeter();
}
