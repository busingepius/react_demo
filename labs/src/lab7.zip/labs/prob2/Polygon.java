package lesson7.labs.prob2;

public interface Polygon {
    public default double[] getSides(){
        return new double[]{};
    };
    public default double computePerimeter() {
        double totalSides = 0.0;
        for(double side : getSides()){
            totalSides += side;
        }
        return totalSides;
    }
}
